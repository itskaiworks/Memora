package com.example.memora

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Where captured photos live on disk. Everything goes in the app's own external files dir, so the
 * photos are removed with the app and need no storage permission.
 */
object PhotoStore {

    private fun photosDir(context: Context): File =
        File(context.getExternalFilesDir(null), "photos").apply { mkdirs() }

    fun newPhotoFile(context: Context): File =
        File(photosDir(context), "IMG_${System.currentTimeMillis()}.jpg")

    /** The camera app can't write to our private dir directly — it needs a FileProvider uri. */
    fun uriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    /**
     * Copies a gallery pick into our own directory. The picker's uri is a temporary grant, so
     * storing it in the database would leave a broken reference after a reboot.
     */
    fun importFrom(context: Context, source: Uri): File? = runCatching {
        val target = newPhotoFile(context)
        context.contentResolver.openInputStream(source)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: return null
        target
    }.getOrNull()
}

/** Handle returned by [rememberPhotoPicker] for triggering the camera or the gallery. */
class PhotoPicker internal constructor(
    private val onCapture: () -> Unit,
    private val onPick: () -> Unit
) {
    fun takePhoto() = onCapture()
    fun chooseFromGallery() = onPick()
}

/**
 * Wires up the camera and the system photo picker. [onPhotoReady] receives the absolute path of a
 * file this app owns, ready to be written straight into the database.
 *
 * Neither path needs a runtime permission: the camera runs through ACTION_IMAGE_CAPTURE (which
 * only requires CAMERA when the app declares that permission, and we don't), and the photo picker
 * hands back a single uri the user explicitly chose.
 */
@Composable
fun rememberPhotoPicker(onPhotoReady: (String) -> Unit): PhotoPicker {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingFile by remember { mutableStateOf<File?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { saved ->
        val file = pendingFile
        pendingFile = null
        if (saved && file != null && file.length() > 0L) {
            onPhotoReady(file.absolutePath)
        } else {
            file?.delete()
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val copied = withContext(Dispatchers.IO) { PhotoStore.importFrom(context, uri) }
                if (copied != null) onPhotoReady(copied.absolutePath)
            }
        }
    }

    return remember(context) {
        PhotoPicker(
            onCapture = {
                val file = PhotoStore.newPhotoFile(context)
                pendingFile = file
                cameraLauncher.launch(PhotoStore.uriFor(context, file))
            },
            onPick = {
                galleryLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            }
        )
    }
}
