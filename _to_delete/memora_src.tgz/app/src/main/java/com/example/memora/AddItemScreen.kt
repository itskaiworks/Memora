package com.example.memora

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * "SELECT WHAT TO ADD" — the hub the centre + button opens (Figma: ADD PAGE).
 *
 * Before this existed the + went straight to the add-item form, which made Add Room and Add
 * Storage reachable only through Profile — and left a first-time user stuck, because an item
 * cannot be filed until at least one room exists.
 */
@Composable
fun AddChooserScreen(
    onBackClick: () -> Unit = {},
    onAddItemClick: () -> Unit = {},
    onAddRoomClick: () -> Unit = {},
    onAddStorageClick: () -> Unit = {}
) {
    AddFlowScaffold(title = "SELECT WHAT TO ADD", onBackClick = onBackClick) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(vertical = 24.dp)
        ) {
            AddChoiceTile(
                label = "ADD ITEM",
                imageRes = R.drawable.house_keys_photo,
                onClick = onAddItemClick
            )
            AddChoiceTile(
                label = "ADD ROOM",
                imageRes = R.drawable.living_room_photo,
                onClick = onAddRoomClick
            )
            AddChoiceTile(
                label = "ADD STORAGE",
                imageRes = R.drawable.first_cabinet_photo,
                onClick = onAddStorageClick
            )
        }
    }
}

@Composable
private fun AddChoiceTile(
    label: String,
    imageRes: Int,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(width = 150.dp, height = 118.dp)
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp), clip = false)
                .clip(RoundedCornerShape(16.dp))
                .background(PlaceholderSand)
                .border(2.dp, DarkGreen, RoundedCornerShape(16.dp))
        ) {
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            color = AccentBrown,
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )
    }
}
