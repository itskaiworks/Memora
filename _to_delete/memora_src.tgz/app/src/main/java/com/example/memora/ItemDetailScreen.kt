package com.example.memora

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.example.memora.data.ItemWithLocation
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * "SEE EXACT LOCATION" — one saved item, read straight from the database by id.
 *
 * It used to be handed its text through navigation arguments copied off a decorative sample list,
 * which meant it had no item id: EDIT could not persist, the heart did nothing, and "I FOUND IT!"
 * only popped the back stack. Everything here now acts on a real row.
 */
@Composable
fun ItemDetailScreen(
    entry: ItemWithLocation,
    onBackClick: () -> Unit = {},
    onEditClick: () -> Unit = {},
    onToggleFavorite: () -> Unit = {},
    onFoundClick: () -> Unit = {}
) {
    val item = entry.item
    val lastRecorded = remember(item.lastUpdatedAt) {
        SimpleDateFormat("MMMM d, yyyy - h:mm a", Locale.getDefault())
            .format(Date(item.lastUpdatedAt))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Image(
            painter = painterResource(id = R.drawable.bg_stripes),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(50.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.DarkGray,
                    modifier = Modifier
                        .size(24.dp)
                        .clickable { onBackClick() }
                )

                Spacer(modifier = Modifier.width(12.dp))

                Text(
                    text = item.name.uppercase(),
                    color = DarkGreen,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )

                Icon(
                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (item.isFavorite) Color(0xFF3A3A3A) else SubTextGray,
                    modifier = Modifier
                        .size(24.dp)
                        .clickable { onToggleFavorite() }
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                        .shadow(elevation = 4.dp, shape = RoundedCornerShape(10.dp), clip = false)
                        .clip(RoundedCornerShape(10.dp))
                        .background(PlaceholderSand),
                    contentAlignment = Alignment.Center
                ) {
                    if (item.photoPath != null) {
                        AsyncImage(
                            model = rememberPhotoModel(item.photoPath),
                            contentDescription = item.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(text = "NO PHOTO", color = SubTextGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(FieldCream)
                        .border(2.dp, DarkGreen, RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = (item.description ?: "No note for this item yet.").uppercase(),
                        fontSize = 13.sp,
                        color = DarkGreen
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LocationTag(entry.roomName?.uppercase() ?: "UNFILED")
                    if (entry.storageName != null) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = DarkGreen,
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                        LocationTag(entry.storageName.uppercase())
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "LAST RECORDED", fontSize = 11.sp, color = SubTextGray, fontWeight = FontWeight.Bold)
                Text(text = lastRecorded, fontSize = 14.sp, color = DarkGreen, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(24.dp))
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 24.dp)
            ) {
                OutlinedButton(
                    onClick = onEditClick,
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = FieldCream,
                        contentColor = Color.DarkGray
                    ),
                    border = BorderStroke(1.dp, DarkGreen),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text(text = "EDIT", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = onFoundClick,
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkGreen),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text(
                        text = "I FOUND IT!",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun LocationTag(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(FieldCream)
            .border(2.dp, DarkGreen, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text = text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = DarkGreen)
    }
}
