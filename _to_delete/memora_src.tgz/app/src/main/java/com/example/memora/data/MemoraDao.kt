package com.example.memora.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoraDao {

    @Query("SELECT * FROM rooms ORDER BY name ASC")
    fun rooms(): Flow<List<RoomEntity>>

    @Query(
        """
        SELECT rooms.*, COUNT(items.id) AS itemCount
        FROM rooms
        LEFT JOIN items ON items.roomId = rooms.id
        GROUP BY rooms.id
        ORDER BY rooms.name ASC
        """
    )
    fun roomsWithCount(): Flow<List<RoomWithCount>>

    @Query("SELECT * FROM storages WHERE roomId = :roomId ORDER BY name ASC")
    fun storagesInRoom(roomId: Long): Flow<List<StorageEntity>>

    @Query(
        """
        SELECT items.*, rooms.name AS roomName, storages.name AS storageName
        FROM items
        LEFT JOIN rooms ON rooms.id = items.roomId
        LEFT JOIN storages ON storages.id = items.storageId
        ORDER BY items.addedAt DESC
        """
    )
    fun items(): Flow<List<ItemWithLocation>>

    @Query(
        """
        SELECT items.*, rooms.name AS roomName, storages.name AS storageName
        FROM items
        LEFT JOIN rooms ON rooms.id = items.roomId
        LEFT JOIN storages ON storages.id = items.storageId
        WHERE items.isFavorite = 1
        ORDER BY items.addedAt DESC
        """
    )
    fun favorites(): Flow<List<ItemWithLocation>>

    @Query(
        """
        SELECT items.*, rooms.name AS roomName, storages.name AS storageName
        FROM items
        LEFT JOIN rooms ON rooms.id = items.roomId
        LEFT JOIN storages ON storages.id = items.storageId
        ORDER BY items.lastUpdatedAt DESC
        LIMIT :limit
        """
    )
    fun recent(limit: Int): Flow<List<ItemWithLocation>>

    @Query(
        """
        SELECT items.*, rooms.name AS roomName, storages.name AS storageName
        FROM items
        LEFT JOIN rooms ON rooms.id = items.roomId
        LEFT JOIN storages ON storages.id = items.storageId
        WHERE items.id = :itemId
        """
    )
    suspend fun itemById(itemId: Long): ItemWithLocation?

    @Query("SELECT * FROM rooms WHERE id = :roomId")
    suspend fun roomById(roomId: Long): RoomEntity?

    @Query("SELECT * FROM storages WHERE id = :storageId")
    suspend fun storageById(storageId: Long): StorageEntity?

    @Insert
    suspend fun insertRoom(room: RoomEntity): Long

    @Insert
    suspend fun insertStorage(storage: StorageEntity): Long

    @Insert
    suspend fun insertItem(item: ItemEntity): Long

    @Query("UPDATE items SET isFavorite = :isFavorite, lastUpdatedAt = :updatedAt WHERE id = :itemId")
    suspend fun setFavorite(itemId: Long, isFavorite: Boolean, updatedAt: Long)

    @Query("UPDATE items SET isFound = 1, lastUpdatedAt = :updatedAt WHERE id = :itemId")
    suspend fun markFound(itemId: Long, updatedAt: Long)

    @Delete
    suspend fun deleteRoom(room: RoomEntity)

    @Query("SELECT * FROM storages ORDER BY name ASC")
    fun storages(): Flow<List<StorageEntity>>

    @Query(
        """
        SELECT storages.*, rooms.name AS roomName, COUNT(items.id) AS itemCount
        FROM storages
        LEFT JOIN rooms ON rooms.id = storages.roomId
        LEFT JOIN items ON items.storageId = storages.id
        GROUP BY storages.id
        ORDER BY storages.name ASC
        """
    )
    fun storagesWithRoom(): Flow<List<StorageWithRoom>>

    /**
     * Matches the query against the item name, its note, and the room/storage it is filed in, so
     * "kitchen" finds everything in the kitchen and not just an item called kitchen.
     */
    @Query(
        """
        SELECT items.*, rooms.name AS roomName, storages.name AS storageName
        FROM items
        LEFT JOIN rooms ON rooms.id = items.roomId
        LEFT JOIN storages ON storages.id = items.storageId
        WHERE items.name LIKE '%' || :query || '%'
           OR items.description LIKE '%' || :query || '%'
           OR rooms.name LIKE '%' || :query || '%'
           OR storages.name LIKE '%' || :query || '%'
        ORDER BY items.lastUpdatedAt DESC
        """
    )
    fun search(query: String): Flow<List<ItemWithLocation>>

    /**
     * A flow rather than a one-shot read: the detail screen has to redraw itself after EDIT,
     * favouriting or "I FOUND IT!" write to the row it is showing. It returns a list rather than a
     * nullable row because a deleted item should emit "nothing", which Room expresses as an empty
     * result set.
     */
    @Query(
        """
        SELECT items.*, rooms.name AS roomName, storages.name AS storageName
        FROM items
        LEFT JOIN rooms ON rooms.id = items.roomId
        LEFT JOIN storages ON storages.id = items.storageId
        WHERE items.id = :itemId
        """
    )
    fun itemRows(itemId: Long): Flow<List<ItemWithLocation>>

    @Query("SELECT * FROM events ORDER BY createdAt DESC")
    fun events(): Flow<List<EventEntity>>

    @Insert
    suspend fun insertEvent(event: EventEntity): Long

    @Query(
        """
        UPDATE items
        SET name = :name, description = :description, roomId = :roomId,
            storageId = :storageId, lastUpdatedAt = :updatedAt
        WHERE id = :itemId
        """
    )
    suspend fun updateItem(
        itemId: Long,
        name: String,
        description: String?,
        roomId: Long?,
        storageId: Long?,
        updatedAt: Long
    )

    @Query("DELETE FROM items WHERE id = :itemId")
    suspend fun deleteItem(itemId: Long)

    @Delete
    suspend fun deleteStorage(storage: StorageEntity)

    @Query("SELECT COUNT(*) FROM rooms")
    suspend fun roomCount(): Int
}
