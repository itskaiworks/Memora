package com.example.memora

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.memora.data.EventEntity
import com.example.memora.data.ItemWithLocation
import com.example.memora.data.MemoraDatabase
import com.example.memora.data.MemoraRepository
import com.example.memora.data.RoomEntity
import com.example.memora.data.RoomWithCount
import com.example.memora.data.StorageEntity
import com.example.memora.data.StorageWithRoom
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** A room the user has filled in but not saved yet, on the way to Add Storage. */
data class RoomDraft(val name: String, val photoPath: String?)

/**
 * The item being built across the three steps of the add-item flow
 * (capture photo -> name it -> file it in a room and storage).
 *
 * It lives on the view model rather than in each screen's `remember`, because the flow spans three
 * navigation destinations and can detour into Add Room / Add Storage and come back.
 */
data class ItemDraft(
    val photoPath: String? = null,
    val name: String = "",
    val roomId: Long? = null,
    val storageId: Long? = null,
    val note: String = ""
)

/** What was just saved, so the confirmation screen can describe it. */
data class SavedSummary(
    val heading: String,
    val categoryLabel: String,
    val roomName: String?,
    val storageName: String?,
    val primaryPhoto: String?,
    val secondaryPhoto: String? = null,
    /** Render the two-photo room-and-storage layout, even before either photo is taken. */
    val paired: Boolean = false,
    val savedAt: Long = System.currentTimeMillis()
)

/**
 * One view model for the whole app, created once by [MainActivity] and handed to every
 * destination.
 *
 * It must NOT be obtained with `viewModel()` inside a `composable { }` block: there the owner is
 * the NavBackStackEntry, so every destination would get its own instance and the state handed
 * between screens — [pendingRoom], [itemDraft], [lastSaved] — would never arrive.
 */
class MemoraViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MemoraRepository(MemoraDatabase.get(application).memoraDao())

    /**
     * Eagerly, not WhileSubscribed: a screen that sits off the back stack longer than a stop
     * timeout would otherwise come back to a stale cached value before the re-query lands. These
     * are small queries over a local database, so keeping them hot costs nothing.
     */
    private fun <T> stateOf(flow: Flow<T>, initial: T): StateFlow<T> =
        flow.stateIn(viewModelScope, SharingStarted.Eagerly, initial)

    val rooms: StateFlow<List<RoomEntity>> = stateOf(repository.rooms, emptyList())
    val roomsWithCount: StateFlow<List<RoomWithCount>> = stateOf(repository.roomsWithCount, emptyList())
    val storagesWithRoom: StateFlow<List<StorageWithRoom>> = stateOf(repository.storagesWithRoom, emptyList())
    val items: StateFlow<List<ItemWithLocation>> = stateOf(repository.items, emptyList())
    val favorites: StateFlow<List<ItemWithLocation>> = stateOf(repository.favorites, emptyList())
    val recentlyAdded: StateFlow<List<ItemWithLocation>> = stateOf(repository.recent(), emptyList())
    val events: StateFlow<List<EventEntity>> = stateOf(repository.events, emptyList())

    private val _lastSaved = MutableStateFlow<SavedSummary?>(null)
    val lastSaved: StateFlow<SavedSummary?> = _lastSaved.asStateFlow()

    private val _pendingRoom = MutableStateFlow<RoomDraft?>(null)
    val pendingRoom: StateFlow<RoomDraft?> = _pendingRoom.asStateFlow()

    private val _itemDraft = MutableStateFlow(ItemDraft())
    val itemDraft: StateFlow<ItemDraft> = _itemDraft.asStateFlow()

    init {
        viewModelScope.launch { repository.seedIfEmpty() }
    }

    fun storagesInRoom(roomId: Long) = repository.storagesInRoom(roomId)

    fun itemFlow(itemId: Long) = repository.itemFlow(itemId)

    fun search(query: String) = repository.search(query)

    // ---------------------------------------------------------------- add-item flow

    fun startItemDraft() {
        _itemDraft.value = ItemDraft()
    }

    fun setDraftPhoto(path: String?) {
        _itemDraft.value = _itemDraft.value.copy(photoPath = path)
    }

    fun setDraftName(name: String) {
        _itemDraft.value = _itemDraft.value.copy(name = name)
    }

    fun setDraftLocation(roomId: Long?, storageId: Long?, note: String) {
        _itemDraft.value = _itemDraft.value.copy(roomId = roomId, storageId = storageId, note = note)
    }

    /** Saves the draft assembled across the add-item steps and prepares the confirmation. */
    fun saveDraftItem(onSaved: () -> Unit = {}) {
        val draft = _itemDraft.value
        if (draft.name.isBlank()) return
        saveItem(
            itemName = draft.name,
            roomId = draft.roomId,
            storageId = draft.storageId,
            photoPath = draft.photoPath,
            description = draft.note,
            onSaved = {
                _itemDraft.value = ItemDraft()
                onSaved()
            }
        )
    }

    // ---------------------------------------------------------------- writes

    /**
     * Saves a room, and optionally the storage the user chained on from the Add Room screen.
     * [onSaved] fires once the confirmation summary is ready.
     */
    fun saveRoom(
        roomName: String,
        roomPhoto: String?,
        storageName: String? = null,
        storagePhoto: String? = null,
        onSaved: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val roomId = repository.saveRoom(roomName, roomPhoto)
            val storage = storageName?.trim()?.takeIf { it.isNotEmpty() }
            if (storage != null) {
                repository.saveStorage(roomId, storage, storagePhoto)
            }
            _pendingRoom.value = null
            _lastSaved.value = SavedSummary(
                heading = if (storage != null) "ROOM & STORAGE  SAVED!" else "ROOM SAVED",
                categoryLabel = if (storage != null) "ROOM & STORAGE" else "ROOM",
                roomName = roomName.trim().uppercase(),
                storageName = storage?.uppercase(),
                primaryPhoto = roomPhoto,
                secondaryPhoto = storagePhoto,
                paired = storage != null
            )
            onSaved()
        }
    }

    fun saveStorage(
        roomId: Long,
        storageName: String,
        storagePhoto: String?,
        onSaved: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.saveStorage(roomId, storageName, storagePhoto)
            val room = repository.roomById(roomId)
            _lastSaved.value = SavedSummary(
                heading = "STORAGE SAVED!",
                categoryLabel = "STORAGE",
                roomName = room?.name?.uppercase(),
                storageName = storageName.trim().uppercase(),
                primaryPhoto = room?.photoPath,
                secondaryPhoto = storagePhoto,
                paired = true
            )
            onSaved()
        }
    }

    fun saveItem(
        itemName: String,
        roomId: Long?,
        storageId: Long?,
        photoPath: String?,
        description: String? = null,
        onSaved: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.saveItem(itemName, roomId, storageId, photoPath, description)
            _lastSaved.value = SavedSummary(
                heading = "ITEM SAVED!",
                categoryLabel = itemName.trim().uppercase(),
                roomName = roomId?.let { repository.roomById(it)?.name?.uppercase() },
                storageName = storageId?.let { repository.storageById(it)?.name?.uppercase() },
                primaryPhoto = photoPath
            )
            onSaved()
        }
    }

    fun updateItem(
        itemId: Long,
        name: String,
        description: String?,
        roomId: Long?,
        storageId: Long?,
        onUpdated: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.updateItem(itemId, name, description, roomId, storageId)
            onUpdated()
        }
    }

    fun deleteItem(itemId: Long, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteItem(itemId)
            onDeleted()
        }
    }

    /** Called when ADD STORAGE is tapped on Add Room, so Add Storage knows to chain. */
    fun startStorageForNewRoom(name: String, photoPath: String?) {
        _pendingRoom.value = RoomDraft(name, photoPath)
    }

    fun clearPendingRoom() {
        _pendingRoom.value = null
    }

    fun deleteRoom(room: RoomEntity) {
        viewModelScope.launch { repository.deleteRoom(room) }
    }

    fun deleteStorage(storage: StorageEntity) {
        viewModelScope.launch { repository.deleteStorage(storage) }
    }

    fun clearLastSaved() {
        _lastSaved.value = null
    }

    fun toggleFavorite(item: ItemWithLocation) {
        viewModelScope.launch { repository.setFavorite(item.item.id, !item.item.isFavorite) }
    }

    fun setFavorite(itemId: Long, isFavorite: Boolean) {
        viewModelScope.launch { repository.setFavorite(itemId, isFavorite) }
    }

    /** "I FOUND IT!" on the detail screen. */
    fun markFound(itemId: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.markFound(itemId)
            onDone()
        }
    }
}
