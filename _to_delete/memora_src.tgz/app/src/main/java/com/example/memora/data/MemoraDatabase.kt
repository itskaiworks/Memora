package com.example.memora.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [RoomEntity::class, StorageEntity::class, ItemEntity::class, EventEntity::class],
    // 2: adds the events table behind the History screen.
    version = 2,
    exportSchema = false
)
abstract class MemoraDatabase : RoomDatabase() {

    abstract fun memoraDao(): MemoraDao

    companion object {
        @Volatile
        private var instance: MemoraDatabase? = null

        fun get(context: Context): MemoraDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MemoraDatabase::class.java,
                    "memora.db"
                )
                    // Nothing shipped yet, so there is no user data worth migrating between
                    // schema versions; rebuilding is preferable to crashing on launch.
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
    }
}
