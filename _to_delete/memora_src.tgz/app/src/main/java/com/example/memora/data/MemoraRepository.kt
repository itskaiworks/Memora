package com.example.memora.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Thin wrapper around [MemoraDao]. Holds no state of its own — every call goes straight to Room.
 *
 * Anything that changes an item also writes an [EventEntity], so the History screen is a record of
 * what happened rather than a separate list that has to be kept in sync by hand.
 */
class MemoraRepository(private val dao: MemoraDao) {

    val rooms: Flow<List<RoomEntity>> = dao.rooms()
    val roomsWithCount: Flow<List<RoomWithCount>> = dao.roomsWithCount()
    val storages: Flow<List<StorageEntity>> = dao.storages()
    val storagesWithRoom: Flow<List<StorageWithRoom>> = dao.storagesWithRoom()
    val items: Flow<List<ItemWithLocation>> = dao.items()
    val favorites: Flow<List<ItemWithLocation>> = dao.favorites()
    val events: Flow<List<EventEntity>> = dao.events()

    fun recent(limit: Int = 10): Flow<List<ItemWithLocation>> = dao.recent(limit)

    fun storagesInRoom(roomId: Long): Flow<List<StorageEntity>> = dao.storagesInRoom(roomId)

    fun search(query: String): Flow<List<ItemWithLocation>> = dao.search(query.trim())

    fun itemFlow(itemId: Long): Flow<ItemWithLocation?> =
        dao.itemRows(itemId).map { it.firstOrNull() }

    suspend fun itemById(itemId: Long): ItemWithLocation? = dao.itemById(itemId)

    suspend fun roomById(roomId: Long): RoomEntity? = dao.roomById(roomId)

    suspend fun storageById(storageId: Long): StorageEntity? = dao.storageById(storageId)

    /** Nothing to backfill — the app starts empty and fills in as the user adds things. */
    suspend fun seedIfEmpty() {
        // Intentionally left empty: no fabricated demo data.
    }

    suspend fun saveRoom(roomName: String, roomPhoto: String?): Long =
        dao.insertRoom(RoomEntity(name = roomName.trim(), photoPath = roomPhoto))

    suspend fun saveStorage(roomId: Long, storageName: String, storagePhoto: String?): Long =
        dao.insertStorage(StorageEntity(roomId = roomId, name = storageName.trim(), photoPath = storagePhoto))

    suspend fun saveItem(
        itemName: String,
        roomId: Long?,
        storageId: Long?,
        photoPath: String?,
        description: String? = null
    ): Long {
        val id = dao.insertItem(
            ItemEntity(
                name = itemName.trim(),
                description = description?.trim()?.takeIf { it.isNotEmpty() },
                photoPath = photoPath,
                roomId = roomId,
                storageId = storageId
            )
        )
        logEvent(id, ItemAction.ADDED)
        return id
    }

    suspend fun updateItem(
        itemId: Long,
        name: String,
        description: String?,
        roomId: Long?,
        storageId: Long?
    ) {
        dao.updateItem(
            itemId = itemId,
            name = name.trim(),
            description = description?.trim()?.takeIf { it.isNotEmpty() },
            roomId = roomId,
            storageId = storageId,
            updatedAt = System.currentTimeMillis()
        )
        logEvent(itemId, ItemAction.EDITED)
    }

    /** The history line is written *before* the delete, so it can still read the item's location. */
    suspend fun deleteItem(itemId: Long) {
        logEvent(itemId, ItemAction.DELETED)
        dao.deleteItem(itemId)
    }

    suspend fun deleteRoom(room: RoomEntity) = dao.deleteRoom(room)

    suspend fun deleteStorage(storage: StorageEntity) = dao.deleteStorage(storage)

    suspend fun setFavorite(itemId: Long, isFavorite: Boolean) =
        dao.setFavorite(itemId, isFavorite, System.currentTimeMillis())

    suspend fun markFound(itemId: Long) {
        dao.markFound(itemId, System.currentTimeMillis())
        logEvent(itemId, ItemAction.RETRIEVED)
    }

    private suspend fun logEvent(itemId: Long, action: ItemAction) {
        val row = dao.itemById(itemId) ?: return
        dao.insertEvent(
            EventEntity(
                itemId = itemId,
                itemName = row.item.name,
                roomName = row.roomName,
                storageName = row.storageName,
                description = row.item.description,
                action = action.name
            )
        )
    }
}
