package com.example.memora

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class ProfileMenuEntry(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color
)

private val menuEntries = listOf(
    ProfileMenuEntry("MY ROOMS", "Manage your rooms", Icons.Default.MeetingRoom, PlaceholderWalnut),
    ProfileMenuEntry("MY STORAGE", "Manage storage locations", Icons.Default.Inventory2, PlaceholderTan),
    ProfileMenuEntry("FAVORITES", "Your favorite items", Icons.Default.Star, PlaceholderCamel)
)

@Composable
fun ProfileScreen(
    username: String = "USERNAME",
    email: String = "username@address.com",
    onHomeClick: () -> Unit = {},
    onAllItemsClick: () -> Unit = {},
    onHistoryClick: () -> Unit = {},
    onAddClick: () -> Unit = {},
    onMyRoomsClick: () -> Unit = {},
    onMyStorageClick: () -> Unit = {},
    onFavoritesClick: () -> Unit = {},
    onLogOutClick: () -> Unit = {}
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.bg_stripes),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(top = 52.dp)
            ) {
                Text(
                    text = "PROFILE",
                    color = DarkGreen,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                Icon(
                    imageVector = Icons.Default.PhotoCamera,
                    contentDescription = "Edit photo",
                    tint = DarkGreen,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                PlaceholderPhoto(
                    color = PlaceholderTan,
                    cornerRadius = 60,
                    modifier = Modifier.size(96.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = username, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen)
                Text(text = email, fontSize = 11.sp, color = SubTextGray)
            }

            Spacer(modifier = Modifier.height(28.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                menuEntries.forEach { entry ->
                    val onClick = when (entry.title) {
                        "MY ROOMS" -> onMyRoomsClick
                        "MY STORAGE" -> onMyStorageClick
                        else -> onFavoritesClick
                    }
                    ProfileMenuRow(entry = entry, onClick = onClick)
                    Spacer(modifier = Modifier.height(10.dp))
                }

                HorizontalDivider(color = CardStroke)
                Spacer(modifier = Modifier.height(10.dp))

                ProfileMenuRow(
                    entry = ProfileMenuEntry("LOG OUT", "Sign out of Memora", Icons.AutoMirrored.Filled.Logout, DarkGreen),
                    onClick = onLogOutClick,
                    iconIsOutline = true
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            MemoraBottomNavBar(
                selectedTab = BottomNavTab.PROFILE,
                onHomeClick = onHomeClick,
                onAllItemsClick = onAllItemsClick,
                onHistoryClick = onHistoryClick,
                onProfileClick = {},
                onAddClick = onAddClick
            )
        }
    }
}

@Composable
private fun ProfileMenuRow(
    entry: ProfileMenuEntry,
    onClick: () -> Unit,
    iconIsOutline: Boolean = false
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp)
    ) {
        if (iconIsOutline) {
            Icon(
                imageVector = entry.icon,
                contentDescription = entry.title,
                tint = entry.color,
                modifier = Modifier.size(36.dp)
            )
        } else {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(entry.color),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = entry.icon,
                    contentDescription = entry.title,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = entry.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DarkGreen)
            Text(text = entry.subtitle, fontSize = 10.sp, color = SubTextGray)
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = SubTextGray
        )
    }
}
