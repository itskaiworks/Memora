package com.example.memora

import androidx.compose.ui.graphics.Color

val DarkGreen = Color(0xFF2C3B20)
val FieldCream = Color(0xFFFCFAF4)
val TitleGray = Color(0xFFB8B8B8)
val SubTextGray = Color(0xFF9C9C9C)
val AccentBrown = Color(0xFF5C4A32)
val CardStroke = Color(0xFFE3DFD3)

// Placeholder tile colors used for items/rooms without a photo yet — same warm neutral
// family already used inline in HomeScreen.
val PlaceholderEspresso = Color(0xFF5C4A32)
val PlaceholderCamel = Color(0xFFB7AC90)
val PlaceholderTan = Color(0xFFCFC2A8)
val PlaceholderWalnut = Color(0xFFA79E80)
val PlaceholderLightBrown = Color(0xFFD9CBB3)
val PlaceholderSand = Color(0xFFE7E1D3)
val PlaceholderBlack = Color(0xFF3D3A32)
