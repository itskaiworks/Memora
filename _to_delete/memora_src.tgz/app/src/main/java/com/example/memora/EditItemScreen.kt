package com.example.memora

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.memora.data.ItemWithLocation
import com.example.memora.data.RoomEntity
import com.example.memora.data.StorageWithRoom


/** Which of the edit screen's four overlays is showing, if any (Figma: the five EDIT PAGE frames). */
private enum class EditStage { FORM, CONFIRM_SAVE, CONFIRM_DELETE, SAVED, DELETED }

/**
 * "EDIT PAGE" — change an item's note and where it is filed, or delete it.
 *
 * Both destructive-ish actions go through the confirmation the mockups show, and each ends on its
 * own success card rather than silently popping the back stack.
 */
@Composable
fun EditItemScreen(
    entry: ItemWithLocation,
    rooms: List<RoomEntity>,
    allStorages: List<StorageWithRoom>,
    onBackClick: () -> Unit,
    onSaveConfirmed: (name: String, note: String, roomId: Long?, storageId: Long?) -> Unit,
    onDeleteConfirmed: () -> Unit,
    onDoneAfterSave: () -> Unit,
    onDoneAfterDelete: () -> Unit
) {
    val item = entry.item

    var name by remember(item.id) { mutableStateOf(item.name) }
    var note by remember(item.id) { mutableStateOf(item.description.orEmpty()) }
    var selectedRoom by remember(item.id) { mutableStateOf(rooms.firstOrNull { it.id == item.roomId }) }
    var selectedStorage by remember(item.id) {
        mutableStateOf(allStorages.firstOrNull { it.storage.id == item.storageId }?.storage)
    }
    var stage by remember { mutableStateOf(EditStage.FORM) }

    // The room list arrives a frame after the item on a cold start; pick up the item's own room
    // once it is there, so the picker does not sit on "SELECT ROOM" for an already-filed item.
    LaunchedEffect(rooms, allStorages, item.roomId, item.storageId) {
        if (selectedRoom == null) selectedRoom = rooms.firstOrNull { it.id == item.roomId }
        if (selectedStorage == null) {
            selectedStorage = allStorages.firstOrNull { it.storage.id == item.storageId }?.storage
        }
    }

    val storagesInRoom = remember(allStorages, selectedRoom) {
        allStorages.filter { it.storage.roomId == selectedRoom?.id }.map { it.storage }
    }

    AddFlowScaffold(title = "EDIT ITEM", onBackClick = onBackClick) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            PhotoWell(
                photoPath = item.photoPath,
                contentDescription = item.name,
                size = 170.dp,
                onClick = {},
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(22.dp))

            MemoraNameField(
                value = name,
                onValueChange = { name = it },
                placeholder = "Item Name...",
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            MemoraDropdown(
                label = "SELECT ROOM",
                options = rooms,
                selected = selectedRoom,
                optionLabel = { it.name },
                onSelect = {
                    selectedRoom = it
                    selectedStorage = null
                },
                emptyHint = "No rooms yet",
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            MemoraDropdown(
                label = "SELECT STORAGE",
                options = storagesInRoom,
                selected = selectedStorage,
                optionLabel = { it.name },
                onSelect = { selectedStorage = it },
                emptyHint = if (selectedRoom == null) "Pick a room first" else "No storage in this room",
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "NOTE",
                color = AccentBrown,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                placeholder = { Text("This item is...", color = AccentBrown.copy(alpha = 0.6f)) },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = AccentBrown,
                    unfocusedBorderColor = AccentBrown,
                    focusedTextColor = AccentBrown,
                    unfocusedTextColor = AccentBrown
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))
        }

        MemoraPrimaryButton(
            text = "SAVE CHANGES",
            enabled = name.isNotBlank(),
            onClick = { stage = EditStage.CONFIRM_SAVE },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        MemoraOutlinedButton(
            text = "DELETE ITEM",
            onClick = { stage = EditStage.CONFIRM_DELETE },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 28.dp)
        )
    }

    when (stage) {
        EditStage.FORM -> Unit

        EditStage.CONFIRM_SAVE -> MemoraConfirmCard(
            message = "ARE YOU SURE YOU WANT TO EDIT THIS ITEM?",
            onNo = { stage = EditStage.FORM },
            onYes = {
                onSaveConfirmed(name, note, selectedRoom?.id, selectedStorage?.id)
                stage = EditStage.SAVED
            }
        )

        EditStage.CONFIRM_DELETE -> MemoraConfirmCard(
            message = "ARE YOU SURE YOU WANT TO DELETE THIS ITEM?",
            onNo = { stage = EditStage.FORM },
            onYes = {
                onDeleteConfirmed()
                stage = EditStage.DELETED
            }
        )

        EditStage.SAVED -> MemoraResultCard(message = "ITEM EDITED!", onDone = onDoneAfterSave)

        EditStage.DELETED -> MemoraResultCard(message = "ITEM DELETED!", onDone = onDoneAfterDelete)
    }
}
