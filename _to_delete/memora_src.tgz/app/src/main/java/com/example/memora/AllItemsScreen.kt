package com.example.memora

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.example.memora.data.ItemWithLocation
import com.example.memora.data.RoomEntity

/**
 * "ALL ITEMS" — every saved item, filterable by room. The filter chips are built from the rooms
 * that actually exist rather than a fixed list, so a newly added room can be filtered by at once.
 */
@Composable
fun AllItemsScreen(
    items: List<ItemWithLocation>,
    rooms: List<RoomEntity>,
    onHomeClick: () -> Unit = {},
    onHistoryClick: () -> Unit = {},
    onProfileClick: () -> Unit = {},
    onAddClick: () -> Unit = {},
    onItemClick: (Long) -> Unit = {},
    onSearchClick: () -> Unit = {},
    onMicClick: () -> Unit = {}
) {
    var selectedFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    val roomFilters = remember(rooms) { listOf("ALL") + rooms.map { it.name.uppercase() } }

    // A room can be deleted while its chip is selected; fall back to ALL instead of showing nothing.
    val activeFilter = if (selectedFilter in roomFilters) selectedFilter else "ALL"

    val visibleItems = remember(items, activeFilter) {
        if (activeFilter == "ALL") items
        else items.filter { it.roomName?.uppercase() == activeFilter }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.bg_stripes),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(top = 52.dp)
            ) {
                Text(
                    text = "ALL ITEMS",
                    color = DarkGreen,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                MemoraSearchField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = "Search for an item or a room.",
                    onSearch = onSearchClick,
                    onMicClick = onMicClick,
                    openSearchOnTap = onSearchClick,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                FilterChipRow(
                    labels = roomFilters,
                    selected = activeFilter,
                    onSelect = { selectedFilter = it },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
            }

            if (visibleItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (items.isEmpty()) "No items yet — tap + to add one."
                        else "Nothing filed in this room yet.",
                        color = SubTextGray,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    items(visibleItems, key = { it.item.id }) { entry ->
                        ItemGridCard(entry = entry, onClick = { onItemClick(entry.item.id) })
                    }
                }
            }

            MemoraBottomNavBar(
                selectedTab = BottomNavTab.ALL_ITEMS,
                onHomeClick = onHomeClick,
                onAllItemsClick = {},
                onHistoryClick = onHistoryClick,
                onProfileClick = onProfileClick,
                onAddClick = onAddClick
            )
        }
    }
}

/** Shared by All Items and Favorites — a photo tile with the item's name and where it is filed. */
@Composable
fun ItemGridCard(
    entry: ItemWithLocation,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, DarkGreen, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(90.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(PlaceholderSand)
        ) {
            entry.item.photoPath?.let {
                AsyncImage(
                    model = rememberPhotoModel(it),
                    contentDescription = entry.item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = entry.item.name.uppercase(),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = DarkGreen
        )
        Text(text = locationLabel(entry), fontSize = 11.sp, color = SubTextGray)
    }
}
