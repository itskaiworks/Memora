package com.example.memora

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SignUpScreen(
    onSignUpClick: () -> Unit = {},
    onLoginClick: () -> Unit = {}
) {
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.bg_stripes),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp,),
        ) {
            Spacer(modifier = Modifier.padding(top = 75.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo_memora),
                    contentDescription = "Memora Logo",
                    modifier = Modifier.size(160.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "MEMORA",
                    color = DarkGreen,
                    fontSize = 60.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.offset(y = (-28).dp)
                )

                Text(
                    text = "SIGN UP",
                    color = SubTextGray,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp,
                    modifier = Modifier.offset(y = (-28).dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            MemoraTextField(
                value = username,
                onValueChange = { username = it },
                placeholder = "USERNAME",
                modifier = Modifier.fillMaxWidth().offset(y = (-28).dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            MemoraTextField(
                value = email,
                onValueChange = { email = it },
                placeholder = "EMAIL",
                keyboardType = KeyboardType.Email,
                modifier = Modifier.fillMaxWidth().offset(y = (-28).dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            MemoraTextField(
                value = password,
                onValueChange = { password = it },
                placeholder = "PASSWORD",
                isPassword = true,
                keyboardType = KeyboardType.Password,
                modifier = Modifier.fillMaxWidth().offset(y = (-28).dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            MemoraTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                placeholder = "CONFIRM PASSWORD",
                isPassword = true,
                keyboardType = KeyboardType.Password,
                modifier = Modifier.fillMaxWidth().offset(y = (-28).dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onSignUpClick,
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .offset(y = (-28).dp)
            ) {
                Text(
                    text = "SIGN UP",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f).offset(y = (-28).dp), color = Color.LightGray)
                Text(
                    text = "OR",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 12.dp).offset(y = (-28).dp)
                )
                HorizontalDivider(modifier = Modifier.weight(1f).offset(y = (-28).dp), color = Color.LightGray)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                modifier = Modifier.fillMaxWidth().offset(y = (-52).dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(modifier = Modifier.weight(1f))
                SocialIconCircle(R.drawable.ic_google)
                SocialIconCircle(R.drawable.ic_facebook)
                SocialIconCircle(R.drawable.ic_x)
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Text(text = "Already have an account? ", color = Color.DarkGray, fontSize = 13.sp, modifier = Modifier.offset(y = (-72).dp))
                Text(
                    text = "Login",
                    color = DarkGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.offset(y = (-72).dp).clickable { onLoginClick() }
                )
            }
        }
    }
}
