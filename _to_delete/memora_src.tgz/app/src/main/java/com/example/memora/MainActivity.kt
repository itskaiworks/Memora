package com.example.memora

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.memora.data.ItemWithLocation
import com.example.memora.ui.theme.MemoraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MemoraTheme {
                // Created here, at the activity, so every destination shares one instance. Calling
                // viewModel() inside a composable("...") block scopes it to that NavBackStackEntry
                // instead, which is what previously left the confirmation screen with no summary
                // to show and broke Add Room -> Add Storage chaining.
                val viewModel: MemoraViewModel = viewModel()
                MemoraNavHost(viewModel = viewModel)
            }
        }
    }
}

private object Routes {
    const val LOGIN = "login"
    const val SIGNUP = "signup"
    const val FORGOT_PASSWORD = "forgot_password"

    const val HOME = "home"
    const val ALL_ITEMS = "all_items"
    const val HISTORY = "history"
    const val PROFILE = "profile"

    const val FAVORITES = "favorites"
    const val ROOMS = "rooms"
    const val STORAGES = "storages"

    const val SEARCH = "search"
    const val SEARCH_VOICE = "search_voice"
    const val SEARCH_RESULTS = "search_results"

    const val ADD = "add"
    const val ADD_ITEM_PHOTO = "add_item_photo"
    const val ADD_ITEM_DETAILS = "add_item_details"
    const val ADD_ITEM_LOCATION = "add_item_location"
    const val ADD_ROOM = "add_room"
    const val ADD_STORAGE = "add_storage"

    const val ITEM_DETAIL = "item_detail"
    const val EDIT_ITEM = "edit_item"
    const val SAVED = "saved"

    fun itemDetail(itemId: Long) = "$ITEM_DETAIL/$itemId"
    fun editItem(itemId: Long) = "$EDIT_ITEM/$itemId"

    /** Percent-encodes the query: a raw one containing a space or "/" produces a route that
     *  matches no destination, so searching for "house keys" used to go nowhere. */
    fun searchResults(query: String) = "$SEARCH_RESULTS/${Uri.encode(query)}"

    /** [returnToItem] marks the detour taken from the add-item flow's "+" buttons, so saving a
     *  room or storage returns to the half-finished item instead of ending the flow. */
    fun addRoom(returnToItem: Boolean = false) = "$ADD_ROOM?returnToItem=$returnToItem"
    fun addStorage(returnToItem: Boolean = false) = "$ADD_STORAGE?returnToItem=$returnToItem"
}

/**
 * Switches between the four bottom-nav tabs without growing the back stack.
 *
 * Tapping Home -> All Items -> History -> Profile -> All Items used to push five entries, so Back
 * walked the whole history instead of leaving the app from Home.
 */
private fun NavHostController.switchTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MemoraNavHost(viewModel: MemoraViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.LOGIN) {

        // ------------------------------------------------------------------ auth

        composable(Routes.LOGIN) {
            LoginScreen(
                // popUpTo(inclusive) so Back from Home leaves the app rather than returning to
                // the login form of a session the user is already in.
                onLoginClick = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onForgotPasswordClick = { navController.navigate(Routes.FORGOT_PASSWORD) },
                onSignUpClick = { navController.navigate(Routes.SIGNUP) }
            )
        }

        composable(Routes.SIGNUP) {
            SignUpScreen(
                onSignUpClick = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onLoginClick = { navController.popBackStack() }
            )
        }

        composable(Routes.FORGOT_PASSWORD) {
            ForgotPasswordScreen(
                onBackClick = { navController.popBackStack() },
                onConfirmClick = { navController.popBackStack() },
                onCancelClick = { navController.popBackStack() }
            )
        }

        // ------------------------------------------------------------------ tabs

        composable(Routes.HOME) {
            val recent by viewModel.recentlyAdded.collectAsStateWithLifecycle()
            val favorites by viewModel.favorites.collectAsStateWithLifecycle()
            val rooms by viewModel.roomsWithCount.collectAsStateWithLifecycle()

            HomeScreen(
                recentlyAdded = recent,
                favorites = favorites,
                rooms = rooms,
                onItemClick = { itemId -> navController.navigate(Routes.itemDetail(itemId)) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onAddClick = { navController.navigate(Routes.ADD) },
                onAllItemsClick = { navController.switchTab(Routes.ALL_ITEMS) },
                onHistoryClick = { navController.switchTab(Routes.HISTORY) },
                onProfileClick = { navController.switchTab(Routes.PROFILE) },
                onSearchClick = { navController.navigate(Routes.SEARCH) },
                onVoiceSearchClick = { navController.navigate(Routes.SEARCH_VOICE) }
            )
        }

        composable(Routes.ALL_ITEMS) {
            val items by viewModel.items.collectAsStateWithLifecycle()
            val rooms by viewModel.rooms.collectAsStateWithLifecycle()

            AllItemsScreen(
                items = items,
                rooms = rooms,
                onHomeClick = { navController.switchTab(Routes.HOME) },
                onHistoryClick = { navController.switchTab(Routes.HISTORY) },
                onProfileClick = { navController.switchTab(Routes.PROFILE) },
                onAddClick = { navController.navigate(Routes.ADD) },
                onItemClick = { itemId -> navController.navigate(Routes.itemDetail(itemId)) },
                onSearchClick = { navController.navigate(Routes.SEARCH) },
                onMicClick = { navController.navigate(Routes.SEARCH_VOICE) }
            )
        }

        composable(Routes.HISTORY) {
            val events by viewModel.events.collectAsStateWithLifecycle()

            HistoryScreen(
                events = events,
                onHomeClick = { navController.switchTab(Routes.HOME) },
                onAllItemsClick = { navController.switchTab(Routes.ALL_ITEMS) },
                onProfileClick = { navController.switchTab(Routes.PROFILE) },
                onAddClick = { navController.navigate(Routes.ADD) }
            )
        }

        composable(Routes.PROFILE) {
            ProfileScreen(
                onHomeClick = { navController.switchTab(Routes.HOME) },
                onAllItemsClick = { navController.switchTab(Routes.ALL_ITEMS) },
                onHistoryClick = { navController.switchTab(Routes.HISTORY) },
                onAddClick = { navController.navigate(Routes.ADD) },
                onMyRoomsClick = { navController.navigate(Routes.ROOMS) },
                onMyStorageClick = { navController.navigate(Routes.STORAGES) },
                onFavoritesClick = { navController.navigate(Routes.FAVORITES) },
                onLogOutClick = {
                    // Clear the whole graph: after signing out, Back must not walk back into the
                    // signed-in screens.
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                }
            )
        }

        // ------------------------------------------------------------------ profile sections

        composable(Routes.FAVORITES) {
            val favorites by viewModel.favorites.collectAsStateWithLifecycle()
            FavoritesScreen(
                favorites = favorites,
                onBackClick = { navController.popBackStack() },
                onItemClick = { itemId -> navController.navigate(Routes.itemDetail(itemId)) }
            )
        }

        composable(Routes.ROOMS) {
            val rooms by viewModel.roomsWithCount.collectAsStateWithLifecycle()
            RoomsScreen(
                rooms = rooms,
                onBackClick = { navController.popBackStack() },
                onAddRoomClick = { navController.navigate(Routes.addRoom()) },
                onDeleteRoom = { viewModel.deleteRoom(it) }
            )
        }

        composable(Routes.STORAGES) {
            val storages by viewModel.storagesWithRoom.collectAsStateWithLifecycle()
            StoragesScreen(
                storages = storages,
                onBackClick = { navController.popBackStack() },
                onAddStorageClick = { navController.navigate(Routes.addStorage()) },
                onDeleteStorage = { viewModel.deleteStorage(it) }
            )
        }

        // ------------------------------------------------------------------ search

        composable(Routes.SEARCH) {
            SearchScreen(
                onBackClick = { navController.popBackStack() },
                onSearchSubmit = { query -> navController.navigate(Routes.searchResults(query)) },
                onMicClick = { navController.navigate(Routes.SEARCH_VOICE) }
            )
        }

        composable(Routes.SEARCH_VOICE) {
            SearchVoiceScreen(
                onBackClick = { navController.popBackStack() },
                onQueryCaptured = { query ->
                    navController.navigate(Routes.searchResults(query)) {
                        popUpTo(Routes.SEARCH_VOICE) { inclusive = true }
                    }
                },
                onTypeInsteadClick = {
                    navController.navigate(Routes.SEARCH) {
                        popUpTo(Routes.SEARCH_VOICE) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = "${Routes.SEARCH_RESULTS}/{query}",
            arguments = listOf(navArgument("query") { type = NavType.StringType })
        ) { backStackEntry ->
            val query = backStackEntry.arguments?.getString("query").orEmpty()
            val results by remember(query) { viewModel.search(query) }
                .collectAsStateWithLifecycle(initialValue = emptyList())

            SearchResultsScreen(
                query = query,
                results = results,
                onBackClick = { navController.popBackStack() },
                onResultClick = { itemId -> navController.navigate(Routes.itemDetail(itemId)) }
            )
        }

        // ------------------------------------------------------------------ add flow

        composable(Routes.ADD) {
            AddChooserScreen(
                onBackClick = { navController.popBackStack() },
                onAddItemClick = {
                    viewModel.startItemDraft()
                    navController.navigate(Routes.ADD_ITEM_PHOTO)
                },
                onAddRoomClick = { navController.navigate(Routes.addRoom()) },
                onAddStorageClick = { navController.navigate(Routes.addStorage()) }
            )
        }

        composable(Routes.ADD_ITEM_PHOTO) {
            val draft by viewModel.itemDraft.collectAsStateWithLifecycle()
            CameraCaptureScreen(
                photoPath = draft.photoPath,
                onBackClick = { navController.popBackStack() },
                onPhotoCaptured = { viewModel.setDraftPhoto(it) },
                onNextClick = { navController.navigate(Routes.ADD_ITEM_DETAILS) }
            )
        }

        composable(Routes.ADD_ITEM_DETAILS) {
            val draft by viewModel.itemDraft.collectAsStateWithLifecycle()
            AddItemDetailsScreen(
                photoPath = draft.photoPath,
                itemName = draft.name,
                onNameChange = { viewModel.setDraftName(it) },
                onBackClick = { navController.popBackStack() },
                onNextClick = { navController.navigate(Routes.ADD_ITEM_LOCATION) }
            )
        }

        composable(Routes.ADD_ITEM_LOCATION) {
            val draft by viewModel.itemDraft.collectAsStateWithLifecycle()
            val rooms by viewModel.rooms.collectAsStateWithLifecycle()
            val allStorages by viewModel.storagesWithRoom.collectAsStateWithLifecycle()

            val selectedRoom = rooms.firstOrNull { it.id == draft.roomId }
            val storagesHere = allStorages
                .filter { it.storage.roomId == draft.roomId }
                .map { it.storage }
            val selectedStorage = storagesHere.firstOrNull { it.id == draft.storageId }

            RoomStorageSelectionScreen(
                photoPath = draft.photoPath,
                rooms = rooms,
                storages = storagesHere,
                selectedRoom = selectedRoom,
                selectedStorage = selectedStorage,
                note = draft.note,
                onRoomSelected = { room ->
                    // Changing the room invalidates the storage, which belongs to the old one.
                    viewModel.setDraftLocation(room.id, null, draft.note)
                },
                onStorageSelected = { storage ->
                    viewModel.setDraftLocation(draft.roomId, storage.id, draft.note)
                },
                onNoteChange = { viewModel.setDraftLocation(draft.roomId, draft.storageId, it) },
                onBackClick = { navController.popBackStack() },
                onAddRoomClick = { navController.navigate(Routes.addRoom(returnToItem = true)) },
                onAddStorageClick = { navController.navigate(Routes.addStorage(returnToItem = true)) },
                onSaveClick = {
                    viewModel.saveDraftItem {
                        navController.navigate(Routes.SAVED) {
                            popUpTo(Routes.HOME) { inclusive = false }
                        }
                    }
                }
            )
        }

        composable(
            route = "${Routes.ADD_ROOM}?returnToItem={returnToItem}",
            arguments = listOf(
                navArgument("returnToItem") { type = NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val returnToItem = backStackEntry.arguments?.getBoolean("returnToItem") ?: false

            AddRoomScreen(
                onBackClick = { navController.popBackStack() },
                onSaved = {
                    if (returnToItem) {
                        navController.popBackStack(Routes.ADD_ITEM_LOCATION, inclusive = false)
                    } else {
                        navController.navigate(Routes.SAVED) {
                            popUpTo(Routes.HOME) { inclusive = false }
                        }
                    }
                },
                onAddStorage = { roomName, roomPhoto ->
                    viewModel.startStorageForNewRoom(roomName, roomPhoto)
                    navController.navigate(Routes.addStorage(returnToItem))
                },
                viewModel = viewModel
            )
        }

        composable(
            route = "${Routes.ADD_STORAGE}?returnToItem={returnToItem}",
            arguments = listOf(
                navArgument("returnToItem") { type = NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val returnToItem = backStackEntry.arguments?.getBoolean("returnToItem") ?: false

            AddStorageScreen(
                onBackClick = {
                    // Abandoning the screen must not leave a half-created room queued up for the
                    // next visit.
                    viewModel.clearPendingRoom()
                    navController.popBackStack()
                },
                onSaved = {
                    if (returnToItem) {
                        navController.popBackStack(Routes.ADD_ITEM_LOCATION, inclusive = false)
                    } else {
                        navController.navigate(Routes.SAVED) {
                            popUpTo(Routes.HOME) { inclusive = false }
                        }
                    }
                },
                onAddRoom = { navController.navigate(Routes.addRoom(returnToItem)) },
                viewModel = viewModel
            )
        }

        composable(Routes.SAVED) {
            val summary by viewModel.lastSaved.collectAsStateWithLifecycle()
            val current = summary

            if (current == null) {
                // Belt and braces: without a summary there is nothing to confirm, and rendering
                // nothing would strand the user on a blank screen — which is exactly what the old
                // per-destination view model did on every single save.
                LaunchedEffect(Unit) { navController.popBackStack(Routes.HOME, inclusive = false) }
            } else {
                SavedScreen(
                    summary = current,
                    onDoneClick = {
                        viewModel.clearLastSaved()
                        navController.popBackStack(Routes.HOME, inclusive = false)
                    }
                )
            }
        }

        // ------------------------------------------------------------------ item detail / edit

        composable(
            route = "${Routes.ITEM_DETAIL}/{itemId}",
            arguments = listOf(navArgument("itemId") { type = NavType.LongType })
        ) { backStackEntry ->
            val itemId = backStackEntry.arguments?.getLong("itemId") ?: 0L
            val entry by remember(itemId) { viewModel.itemFlow(itemId) }
                .collectAsStateWithLifecycle(initialValue = null)
            val current = entry

            // Null only while the first query is in flight; the screen fills in a frame later.
            if (current != null) {
                ItemDetailScreen(
                    entry = current,
                    onBackClick = { navController.popBackStack() },
                    onEditClick = { navController.navigate(Routes.editItem(itemId)) },
                    onToggleFavorite = { viewModel.toggleFavorite(current) },
                    onFoundClick = {
                        // Records a RETRIEVED entry in History, then returns to where we came from.
                        viewModel.markFound(itemId) { }
                        navController.popBackStack()
                    }
                )
            }
        }

        composable(
            route = "${Routes.EDIT_ITEM}/{itemId}",
            arguments = listOf(navArgument("itemId") { type = NavType.LongType })
        ) { backStackEntry ->
            val itemId = backStackEntry.arguments?.getLong("itemId") ?: 0L
            val entry by remember(itemId) { viewModel.itemFlow(itemId) }
                .collectAsStateWithLifecycle(initialValue = null)
            val rooms by viewModel.rooms.collectAsStateWithLifecycle()
            val allStorages by viewModel.storagesWithRoom.collectAsStateWithLifecycle()

            // Keep the last row we saw: after DELETE the query goes null, and the screen still has
            // to stay up long enough to show its "ITEM DELETED!" confirmation.
            var lastEntry by remember(itemId) { mutableStateOf<ItemWithLocation?>(null) }
            LaunchedEffect(entry) { entry?.let { lastEntry = it } }

            lastEntry?.let { current ->
                EditItemScreen(
                    entry = current,
                    rooms = rooms,
                    allStorages = allStorages,
                    onBackClick = { navController.popBackStack() },
                    onSaveConfirmed = { name, note, roomId, storageId ->
                        viewModel.updateItem(itemId, name, note, roomId, storageId)
                    },
                    onDeleteConfirmed = { viewModel.deleteItem(itemId) },
                    onDoneAfterSave = { navController.popBackStack() },
                    onDoneAfterDelete = {
                        // The detail screen behind this one is showing a row that no longer
                        // exists, so pop past it rather than back onto it.
                        navController.popBackStack(Routes.HOME, inclusive = false)
                    }
                )
            }
        }
    }
}
