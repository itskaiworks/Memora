package com.example.memora

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LoginScreen(
    onLoginClick: () -> Unit = {},
    onForgotPasswordClick: () -> Unit = {},
    onSignUpClick: () -> Unit = {}
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.bg_stripes),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.height(120.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo_memora),
                    contentDescription = "Memora Logo",
                    modifier = Modifier.size(160.dp)
                )

                Text(
                    text = "MEMORA",
                    color = DarkGreen,
                    fontSize = 60.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.offset(y = (-28).dp)
                )

                Text(
                    text = "LOGIN",
                    color = SubTextGray,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp,
                    modifier = Modifier.offset(y = (-28).dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            MemoraTextField(
                value = email,
                onValueChange = { email = it },
                placeholder = "EMAIL",
                keyboardType = KeyboardType.Email,
                modifier = Modifier.fillMaxWidth().offset(y = (-28).dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            MemoraTextField(
                value = password,
                onValueChange = { password = it },
                placeholder = "PASSWORD",
                isPassword = true,
                keyboardType = KeyboardType.Password,
                modifier = Modifier.fillMaxWidth().offset(y = (-28).dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked = rememberMe,
                    onCheckedChange = { rememberMe = it },
                    colors = CheckboxDefaults.colors(checkedColor = DarkGreen),
                    modifier = Modifier.offset(y = (-28).dp)
                )
                Text(text = "Remember me?", color = Color.DarkGray, fontSize = 13.sp,
                     modifier = Modifier.offset(y = (-28).dp))
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onLoginClick,
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .offset(y = (-28).dp)
            ) {
                Text(
                    text = "LOGIN",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Forgot Password?",
                color = Color.DarkGray,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-28).dp)
                    .clickable { onForgotPasswordClick()}
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f).offset(y = (-28).dp), color = Color.LightGray)
                Text(
                    text = "OR",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 12.dp).offset(y = (-28).dp)
                )
                HorizontalDivider(modifier = Modifier.weight(1f).offset(y = (-28).dp), color = Color.LightGray)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                modifier = Modifier.fillMaxWidth().offset(y = (-28).dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(modifier = Modifier.weight(1f))
                SocialIconCircle(R.drawable.ic_google)
                SocialIconCircle(R.drawable.ic_facebook)
                SocialIconCircle(R.drawable.ic_x)
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.weight(1f))

            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Text(text = "Don't have an account yet? ", color = Color.DarkGray, fontSize = 13.sp, modifier = Modifier.offset(y = (-28).dp))
                Text(
                    text = "Sign Up",
                    color = DarkGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.offset(y = (-28).dp).clickable { onSignUpClick() }
                )
            }
        }
    }
}