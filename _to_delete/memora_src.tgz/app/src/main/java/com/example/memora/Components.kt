package com.example.memora

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MemoraTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = SubTextGray, fontSize = 13.sp) },
        singleLine = true,
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = FieldCream,
            unfocusedContainerColor = FieldCream,
            focusedBorderColor = DarkGreen,
            unfocusedBorderColor = CardStroke
        ),
        modifier = modifier
    )
}

/**
 * The rounded search field.
 *
 * Pass [openSearchOnTap] on screens whose search bar is a shortcut into the search page rather
 * than a field of its own (Home, All Items): the field goes read-only and a tap anywhere except
 * the mic opens the search screen, instead of raising a keyboard for a field that does nothing.
 */
@Composable
fun MemoraSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    onSearch: () -> Unit = {},
    onMicClick: () -> Unit = {},
    openSearchOnTap: (() -> Unit)? = null
) {
  Box(modifier = modifier) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = {
            Text(text = placeholder, color = Color.DarkGray, fontSize = 13.sp)
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = Color.DarkGray,
                modifier = Modifier.clickable { onSearch() }
            )
        },
        trailingIcon = {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Voice Search",
                tint = Color.DarkGray,
                modifier = Modifier.clickable { onMicClick() }
            )
        },
        singleLine = true,
        readOnly = openSearchOnTap != null,
        // Submitting from the keyboard's Search key is what most people reach for; without this
        // the only way to run a search was tapping the small magnifier icon.
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = FieldCream,
            unfocusedContainerColor = FieldCream,
            focusedBorderColor = DarkGreen,
            unfocusedBorderColor = CardStroke
        ),
        modifier = Modifier.fillMaxWidth()
    )

    if (openSearchOnTap != null) {
        // Stops short of the trailing mic so voice search stays reachable.
        Box(
            modifier = Modifier
                .matchParentSize()
                .padding(end = 52.dp)
                .clickable { openSearchOnTap() }
        )
    }
  }
}

@Composable
fun SocialIconCircle(iconRes: Int, onClick: () -> Unit = {}) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(50))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = iconRes),
            contentDescription = null,
            modifier = Modifier.size(48.dp)
        )
    }
}

/** Which tab of [MemoraBottomNavBar] is currently showing. */
enum class BottomNavTab { HOME, ALL_ITEMS, HISTORY, PROFILE }

/**
 * The shared bottom navigation bar used by Home, All Items, History and Profile, with the
 * center "+" button for the add flow. [selectedTab] controls which icon is highlighted.
 */
@Composable
fun MemoraBottomNavBar(
    selectedTab: BottomNavTab,
    onHomeClick: () -> Unit,
    onAllItemsClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onProfileClick: () -> Unit,
    onAddClick: () -> Unit
) {
    Box(modifier = Modifier.fillMaxWidth()) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 42.dp, topEnd = 42.dp))
                .background(Color(0xFFFCFAF4))
                .border(2.dp, Color(0xFF2C3B20), RoundedCornerShape(topStart = 42.dp, topEnd = 42.dp))
                .padding(horizontal = 16.dp, vertical = 13.dp)
        ) {
            BottomNavItem(
                icon = Icons.Default.Home,
                label = "HOME",
                selected = selectedTab == BottomNavTab.HOME,
                onClick = onHomeClick,
                modifier = Modifier.weight(1f)
            )
            BottomNavItem(
                icon = Icons.Default.List,
                label = "ALL ITEMS",
                selected = selectedTab == BottomNavTab.ALL_ITEMS,
                onClick = onAllItemsClick,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.weight(1f))
            BottomNavItem(
                icon = Icons.Default.History,
                label = "HISTORY",
                selected = selectedTab == BottomNavTab.HISTORY,
                onClick = onHistoryClick,
                modifier = Modifier.weight(1f)
            )
            BottomNavItem(
                icon = Icons.Default.Person,
                label = "PROFILE",
                selected = selectedTab == BottomNavTab.PROFILE,
                onClick = onProfileClick,
                modifier = Modifier.weight(1f)
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-22).dp)
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFF2C3B20))
                .padding(2.dp)
                .clip(CircleShape)
                .background(Color(0xFFFCFAF4))
                .clickable { onAddClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add", tint = Color(0xFF2C3B20), modifier = Modifier.size(42.dp))
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.clickable { onClick() }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) DarkGreen else SubTextGray,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) DarkGreen else SubTextGray
        )
    }
}

/** A row of tappable filter chips — used by All Items and History to narrow the list. */
@Composable
fun FilterChipRow(
    labels: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier
    ) {
        items(labels) { label ->
            val isSelected = label == selected
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isSelected) DarkGreen else Color(0xFFFCFAF4))
                    .border(1.dp, DarkGreen, RoundedCornerShape(20.dp))
                    .clickable { onSelect(label) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else DarkGreen
                )
            }
        }
    }
}

/** A colored tile used in place of a real photo, sized and rounded by the caller. */
@Composable
fun PlaceholderPhoto(
    color: Color,
    cornerRadius: Int,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius.dp))
            .background(color)
    )
}

/** A two-line item card for the All Items / Favorites grids. */
@Composable
fun GridItemCard(
    title: String,
    location: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, DarkGreen, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        PlaceholderPhoto(
            color = color,
            cornerRadius = 10,
            modifier = Modifier
                .fillMaxWidth()
                .height(90.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = DarkGreen
        )
        Text(
            text = location,
            fontSize = 11.sp,
            color = SubTextGray
        )
    }
}